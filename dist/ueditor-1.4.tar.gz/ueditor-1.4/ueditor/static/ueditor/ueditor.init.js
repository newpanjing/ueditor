window.onload = function () {
    UE.getEditor('ueditor')
}
