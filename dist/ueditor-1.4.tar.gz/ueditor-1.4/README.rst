**ueditor**

a django RichText plugin.

github:

https://github.com/newpanjing/ueditor



